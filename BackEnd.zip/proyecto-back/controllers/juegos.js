const { request, response } = require('express');

const Juegos = require('../models/juegos');


const getJuegos = async (req = request, res = response ) => {
    try {
        const listaJuegos = await Juegos.find();
        res.status(200).json(listaJuegos);
    } catch (error) {
        res.status(500).json({ error: 'Error en el servidor', error });
    }
}

const postJuegos = async (req = request, res = response) => {
    const { nombre, descripcion} = req.body;

    const juegoGuardadoDB = new Juegos({
        nombre, descripcion
    });

    await juegoGuardadoDB.save();

    res.json({
        msg: 'Post Api - Post Juegos',
        juegoGuardadoDB
    })
}

const putJuegos = async (req = request, res = response) => {
    const { id } = req.params;
    const { _id, ...resto } = req.body;

    const juegoEditado = await Juegos.findByIdAndUpdate(id, resto, { new: true });

    res.json({
        msg: 'Put Api - Put Usuario',
        juegoEditado
    })
}

const deleteJuegos = async (req = request, res = response ) => {
    const { id } = req.params;

    const juegoEliminado = await Juegos.findByIdAndDelete(id);

    res.json({
        msg: 'Delete Api - Delete',
        juegoEliminado
    })
}


module.exports = {
    getJuegos,
    postJuegos,
    putJuegos,
    deleteJuegos
}


