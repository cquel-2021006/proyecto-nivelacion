require('dotenv').config();

const Server = require('./models/server');
const serverIniciado = new Server();

serverIniciado.listen();