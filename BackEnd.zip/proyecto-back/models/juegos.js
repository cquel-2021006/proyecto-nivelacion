const {Schema, model} = require('mongoose');

const JuegosSchema = Schema({
    nombre: {
        type: String,
        required: [true, 'El nombre es obligatorio']
    },
    descripcion: {
        type: String,
        required: [true, 'La descripcion es obligatorio']
    }
})  

module.exports = model('Juegos', JuegosSchema);