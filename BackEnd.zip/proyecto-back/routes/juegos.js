const { Router } = require('express');
const { check } = require('express-validator');

const { getJuegos, postJuegos, putJuegos, deleteJuegos } = require('../controllers/juegos');
const { validarCampos } = require('../middlewares/validar-campos');

const router = Router();

router.get('/mostrar', getJuegos);

router.post('/agregar', [
    check('nombre', 'El nombre es obligatorio').not().isEmpty(),
    check('descripcion', 'La descripcion es obligatoria').not().isEmpty(),
    validarCampos
], postJuegos);

router.put('/editar/:id', [
    check('id', 'No es un ID valido').isMongoId(),
    validarCampos
], putJuegos);

router.delete('/eliminar/:id', [
    check('id', 'No es un ID valido').isMongoId(),
    validarCampos
], deleteJuegos);

module.exports = router;